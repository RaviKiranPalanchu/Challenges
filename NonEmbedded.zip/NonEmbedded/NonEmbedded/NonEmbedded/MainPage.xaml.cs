﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace NonEmbedded
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }


        private async Task<string> GetResponse(string text)
        {
            ValidationResponse validationResponse;
            bool isNumeric = IsAllDigits(text);
            if (isNumeric)
            {
                int input = Convert.ToInt32(text);
                if (input % 7 == 0 && input % 9 == 0)
                {
                    validationResponse = new ValidationResponse()
                    {
                        Status = 1,
                        Message = "CN",
                    };
                    return JsonConvert.SerializeObject(validationResponse);
                }
                else if (input % 7 == 0)
                {
                    validationResponse = new ValidationResponse()
                    {
                        Status = 1,
                        Message = "C",
                    };
                    return JsonConvert.SerializeObject(validationResponse);
                }
                else if (input % 9 == 0)
                {
                    validationResponse = new ValidationResponse()
                    {
                        Status = 1,
                        Message = "N",
                    };
                    return JsonConvert.SerializeObject(validationResponse);
                }
                else
                {
                    validationResponse = new ValidationResponse()
                    {
                        Status = 0,
                        Message = text,
                    };
                    return JsonConvert.SerializeObject(validationResponse);
                }
            }
            else
            {
                validationResponse = new ValidationResponse()
                {
                    Status = 0,
                    Message = text + " is not a valid integer",
                };
                return JsonConvert.SerializeObject(validationResponse);
            }
        }

        bool IsAllDigits(string s)
        {
            foreach (char c in s)
            {
                if (!char.IsDigit(c))
                    return false;
            }
            return true;
        }

        private async void BtnClick_Clicked(object sender, EventArgs e)
        {
            string response = await GetResponse(txtInput.Text);
            ValidationResponse validation = JsonConvert.DeserializeObject<ValidationResponse>(response);
            await DisplayAlert("Response", validation.Message, "OK");
        }
    }

    public class ValidationResponse
    {
        public int Status { get; set; }

        public string Message { get; set; }
    }
}
